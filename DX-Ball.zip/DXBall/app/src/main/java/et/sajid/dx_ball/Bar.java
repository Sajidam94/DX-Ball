package et.sajid.dx_ball;


import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.view.MotionEvent;

public class Bar {
    float top,bottom,left,right;
    Canvas canvas = new Canvas();
    Paint paint;
    Point point;
    int x,y;
    int movingSpeed = 20;

    Bar(){
        left =0;
        top=0;
        right=0;
        bottom=0;
        paint=new Paint();
        paint.setColor(Color.YELLOW);

    }

    public void setBottom(float bottom) {
        this.bottom = bottom;
    }

    public void setLeft(float left) {
        this.left = left;
    }

    public void setRight(float right) {
        this.right = right;
    }

    public void setTop(float top) {
        this.top = top;
    }

    public float getLeft() {
        return left;
    }

    public float getRight() {
        return right;
    }

    public float getBottom() {
        return bottom;
    }

    public Paint getPaint() {
        return paint;
    }

    public float getTop() {
        return top;
    }

    public void moveBar(boolean leftPos,boolean rightPos){
        if(leftPos==true){
            if(DrawCanvas.checkWidth >= right) {
                left = left + movingSpeed;
                right = right + movingSpeed;
            }


        }
        else if(rightPos==true){
            if (0 <=left) {
                left = left - movingSpeed;
                right = right - movingSpeed;
            }

        }

    }
}
